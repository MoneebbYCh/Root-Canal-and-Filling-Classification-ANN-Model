# Root Canal > 2023-09-16 10:27am
https://universe.roboflow.com/md-farhan-hasin-saad/root-canal

Provided by a Roboflow user
License: CC BY 4.0

